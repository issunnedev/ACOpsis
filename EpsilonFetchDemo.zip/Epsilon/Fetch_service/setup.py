import os
import subprocess
import sys
from pathlib import Path
import venv

PROJECT_DIR = Path(__file__).resolve().parent
VENV_DIR = PROJECT_DIR / ".venv"
REQUIREMENTS = PROJECT_DIR / "requirements.txt"
CACHE_DIR = PROJECT_DIR / "youtube_cache"
ENV_FILE = PROJECT_DIR / ".env"


def run(command):
    print(f"\n> {' '.join(map(str, command))}")
    subprocess.run(command, check=True, cwd=PROJECT_DIR)


def get_venv_python():
    if os.name == "nt":
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def create_requirements():
    if REQUIREMENTS.exists():
        print("requirements.txt already exists.")
        return

    REQUIREMENTS.write_text(
        "requests>=2.31.0,<3.0.0\n"
        "python-dotenv>=1.0.0,<2.0.0\n",
        encoding="utf-8",
    )
    print("Created requirements.txt.")


def create_env_file():
    if ENV_FILE.exists():
        print(".env already exists; leaving it unchanged.")
        return

    ENV_FILE.write_text(
        "# Add your YouTube Data API v3 key below\n"
        "YOUTUBE_API_KEY=\n",
        encoding="utf-8",
    )
    print("Created .env. Add your YouTube API key to it.")


def create_gitignore():
    gitignore = PROJECT_DIR / ".gitignore"
    entries = [
        ".venv/",
        ".env",
        "__pycache__/",
        "*.py[cod]",
    ]

    existing = (
        gitignore.read_text(encoding="utf-8").splitlines()
        if gitignore.exists()
        else []
    )

    missing = [entry for entry in entries if entry not in existing]

    if missing:
        with gitignore.open("a", encoding="utf-8") as file:
            if existing and existing[-1].strip():
                file.write("\n")
            file.write("\n".join(missing) + "\n")

    print("Configured .gitignore.")


def main():
    print("=== YouTube Collector Setup ===")

    create_requirements()
    create_env_file()
    create_gitignore()

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Cache directory ready: {CACHE_DIR}")

    if not VENV_DIR.exists():
        print("Creating virtual environment...")
        venv.EnvBuilder(with_pip=True).create(VENV_DIR)
    else:
        print("Virtual environment already exists.")

    python = get_venv_python()

    print("Upgrading pip...")
    run([str(python), "-m", "pip", "install", "--upgrade", "pip"])

    print("Installing dependencies...")
    run([
        str(python),
        "-m",
        "pip",
        "install",
        "-r",
        str(REQUIREMENTS),
    ])

    print("\n=== Setup Complete ===")
    print(f"Project directory: {PROJECT_DIR}")
    print(f"Virtual environment: {VENV_DIR}")
    print(f"Cache directory: {CACHE_DIR}")
    print("\nNext steps:")
    print("1. Add your API key to .env.")
    print("2. Run the collector using the commands below.")

    if os.name == "nt":
        print(
            f'3. Run: "{python}" gather.py '
            '"quick pasta recipes"'
        )
    else:
        print(
            f'3. Run: "{python}" gather.py '
            '"quick pasta recipes"'
        )


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as error:
        sys.exit(f"Setup failed: {error}")
    except OSError as error:
        sys.exit(f"Filesystem or environment error: {error}")